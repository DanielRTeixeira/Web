jQuery(function(){

	var $ = jQuery;
	
	$('#polledit').validate();
	$('ul.polls').masonry();
	
});
